# -*- coding: utf-8 -*-

from odoo import models


class AccountMove(models.Model):
    _inherit = 'account.move'

    def action_print_invoice(self):
        """Action để in hóa đơn - mở preview trong chrome"""
        self.ensure_one()

        # Gọi report action để in PDF
        return self.env.ref('co_invoice_print.invoice_report_action').report_action(self)
