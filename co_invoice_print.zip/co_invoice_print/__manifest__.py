# -*- coding: utf-8 -*-
{
    'name': 'Invoice Print Module',
    'version': '17.0.1.0.0',
    'summary': 'Module in hóa đơn với nút in trong account_move',
    'description': '''
        Module cho phép in hóa đơn với:
        - Nút in trong form view account_move
        - Xem trước hóa đơn trực tiếp trên chrome
    ''',
    'author': 'Dan Huy',
    'category': 'Cookies Module',
    'depends': ['base', 'account'],
    'data': [
        'reports/invoice_report.xml',
        'reports/invoice_template.xml',
        'reports/custom_layout.xml',
        'views/account_move_views.xml',

    ],
    'assets': {
            'web.assets_backend': [
                'co_invoice_print/static/src/css/my_report_styles.css',
            ],
        },
    'installable': True,
    'auto_install': False,
    'application': False,
    'sequence': 100,
}
